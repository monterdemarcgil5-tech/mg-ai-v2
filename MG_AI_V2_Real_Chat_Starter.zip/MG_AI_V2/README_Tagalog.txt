MG AI V2 — REAL AI CHAT STARTER

IMPORTANT:
- This project adds a Netlify serverless function for AI chat.
- The AI chat will NOT work until an adult/parent/guardian helps configure an API account and secret key, if required.
- Never paste an API key into this chat, index.html, a screenshot, or a public file.
- API usage may cost money. Ask a parent/guardian to review costs and set limits before enabling it.
- This project is a prototype, not yet a production-ready public service. Add abuse protection, usage limits, privacy notice, and testing before sharing widely.

DEPLOY:
This version includes a Netlify Function. A simple drag-and-drop static deployment may not deploy serverless functions.
Use a Git-connected Netlify deployment or Netlify CLI/build deployment so netlify/functions/chat.js is deployed.
Set the environment variable OPENAI_API_KEY in Netlify Site configuration > Environment variables. Do not put the key in the source files.
Optional: set OPENAI_MODEL if you want to choose another model available to the account. Default is gpt-5.5.
Redeploy after setting environment variables.

The function calls the OpenAI Responses API from the server. The browser never receives the API key.
Official docs:
https://developers.openai.com/api/docs/quickstart
https://developers.openai.com/api/reference/overview
