exports.handler = async function (event) {
  const headers = {
    "Content-Type": "application/json",
    "Cache-Control": "no-store"
  };
  if (event.httpMethod !== "POST") {
    return { statusCode: 405, headers, body: JSON.stringify({ error: "Use POST for chat." }) };
  }

  const apiKey = process.env.OPENAI_API_KEY;
  if (!apiKey) {
    return { statusCode: 503, headers, body: JSON.stringify({ error: "MG AI's secure AI connection has not been configured yet." }) };
  }

  let body;
  try { body = JSON.parse(event.body || "{}"); }
  catch { return { statusCode: 400, headers, body: JSON.stringify({ error: "Invalid message data." }) }; }

  const messages = Array.isArray(body.messages) ? body.messages : [];
  const safeMessages = messages
    .filter(m => m && (m.role === "user" || m.role === "assistant") && typeof m.content === "string")
    .slice(-12)
    .map(m => ({ role: m.role, content: m.content.slice(0, 2000) }));

  if (!safeMessages.length || safeMessages[safeMessages.length - 1].role !== "user") {
    return { statusCode: 400, headers, body: JSON.stringify({ error: "Please send a message first." }) };
  }

  try {
    const upstream = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { "Authorization": `Bearer ${apiKey}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: process.env.OPENAI_MODEL || "gpt-5.5",
        instructions: "You are MG AI, a friendly, helpful assistant. Reply in the language the user uses, including Filipino or English. Explain school topics clearly and support learning rather than simply doing all the work. Be age-appropriate, respectful, and honest about uncertainty. Do not claim to have performed actions you cannot perform.",
        input: safeMessages.map(m => ({ role: m.role, content: m.content })),
        max_output_tokens: 700
      })
    });
    const result = await upstream.json();
    if (!upstream.ok) {
      return { statusCode: 502, headers, body: JSON.stringify({ error: "The AI provider could not complete the request. Check the server key, model access, and usage limits." }) };
    }
    const reply = typeof result.output_text === "string" ? result.output_text.trim() : "";
    if (!reply) return { statusCode: 502, headers, body: JSON.stringify({ error: "The AI returned an empty reply. Please try again." }) };
    return { statusCode: 200, headers, body: JSON.stringify({ reply }) };
  } catch (err) {
    return { statusCode: 502, headers, body: JSON.stringify({ error: "Could not reach the AI service. Please try again later." }) };
  }
};
